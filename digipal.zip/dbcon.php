<?php

$con = mysqli_connect("localhost","root","","digipal");

if(!$con){
    die('Connection Failed'. mysqli_connect_error());
}

?>