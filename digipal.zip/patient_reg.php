<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>patient registration</title>
    <link rel="stylesheet" href="patientreg.css"/>
</head>
<body>
    <form action="insert_patient.php" method="POST" enctype="multipart/form-data">
        <div class="login-page">
            <input type="text" placeholder="Name" name="name" value=""><br>
            <input type="tel" placeholder="Phone number" name="phone" value=""><br>
            <input type="email" placeholder="Email Address" name="email" value=""><br>
            <input type=password placeholder="Password" name="password" value=""><br>
            <input type="tet" placeholder="Age" name="age" value=""><br>
            <input placeholder="Date of birth" class="textbox-n" type="text" onfocus="(this.type='date')" id="date" name="dob"><br>
            <select id="" name="gender" >
                <option value="" disabled selected>Gender</option>
                <option value="Male">Male</option>
                <option value="Female">Female</option>
                <option value="others">Others</option>
              </select>     
            
<select id="" name="illness" >
  <option value="" disabled selected >Illness type</option>
  <option value="Cancer">Cancer</option>
  <option value="Alzheimers">Alzheimers</option>
  <option value="Cardiac disease">cardiac disease</option>
  <option value="Stroke">Stroke</option>
  <option value="Liver cirrhosis">Liver cirrhosis</option>
  <option value="Parkinson's disease">Parkinson's disease</option>
  <option value="others">others</option>
</select>
            <input type="text" placeholder="Address" name="address" value=""><br>
            
            <input type="text" placeholder="Place" name="place" value=""><br>

            <p style="margin-left: 10%;color:grey"> Upload your health record proof:</p>
            
            <input type="file" id="" name="uploadfile" style="margin-top: 5px;">
            
            <input type="submit" name="upload" value="Register">
          </div>
    </form>
</body>


</html>

<?php
unset($_SESSION['success']);
?>